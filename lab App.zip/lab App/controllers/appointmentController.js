const Appointment = require('../models/Appointment');

class AppointmentController {
  async book(req, res) {
    try {
      const appointment = new Appointment(req.body);
      await appointment.save();
      res.status(201).json(appointment);
    } catch (error) {
      res.status(500).json({ message: 'Failed to book appointment', error });
    }
  }

  async getAll(req, res) {
    try {
      const appointments = await Appointment.find();
      res.status(200).json(appointments);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch appointments', error });
    }
  }

  async update(req, res) {
    try {
      const updated = await Appointment.findByIdAndUpdate(req.params.id, req.body, { new: true });
      res.status(200).json(updated);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update appointment', error });
    }
  }

  async cancel(req, res) {
    try {
      await Appointment.findByIdAndDelete(req.params.id);
      res.status(200).json({ message: 'Appointment cancelled' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to cancel appointment', error });
    }
  }
}

module.exports = new AppointmentController();