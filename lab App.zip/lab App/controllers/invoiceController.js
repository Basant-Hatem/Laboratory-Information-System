const Invoice = require('../models/Invoice');

class InvoiceController {
  async create(req, res) {
    try {
      const invoice = new Invoice(req.body);
      await invoice.save();
      res.status(201).json(invoice);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create invoice', error });
    }
  }

  async getAll(req, res) {
    try {
      const invoices = await Invoice.find();
      res.status(200).json(invoices);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch invoices', error });
    }
  }

  async getById(req, res) {
    try {
      const invoice = await Invoice.findById(req.params.id);
      if (!invoice) return res.status(404).json({ message: 'Invoice not found' });
      res.status(200).json(invoice);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching invoice', error });
    }
  }

  async update(req, res) {
    try {
      const updated = await Invoice.findByIdAndUpdate(req.params.id, req.body, { new: true });
      res.status(200).json(updated);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update invoice', error });
    }
  }
}

module.exports = new InvoiceController();