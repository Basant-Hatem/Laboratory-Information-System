const Test = require('../models/Test');

class TestController {
  async create(req, res) {
    try {
      const test = new Test(req.body);
      await test.save();
      res.status(201).json(test);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create test', error });
    }
  }

  async getAll(req, res) {
    try {
      const tests = await Test.find();
      res.status(200).json(tests);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch tests', error });
    }
  }

  async update(req, res) {
    try {
      const updated = await Test.findByIdAndUpdate(req.params.id, req.body, { new: true });
      res.status(200).json(updated);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update test', error });
    }
  }

  async delete(req, res) {
    try {
      await Test.findByIdAndDelete(req.params.id);
      res.status(200).json({ message: 'Test deleted' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete test', error });
    }
  }
}

module.exports = new TestController();