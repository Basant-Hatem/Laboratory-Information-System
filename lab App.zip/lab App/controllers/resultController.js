const Result = require('../models/Result');

class ResultController {
  async create(req, res) {
    try {
      const result = new Result(req.body);
      await result.save();
      res.status(201).json(result);
    } catch (error) {
      res.status(500).json({ message: 'Failed to add result', error });
    }
  }

  async getAll(req, res) {
    try {
      const results = await Result.find();
      res.status(200).json(results);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch results', error });
    }
  }

  async getById(req, res) {
    try {
      const result = await Result.findById(req.params.id);
      if (!result) return res.status(404).json({ message: 'Result not found' });
      res.status(200).json(result);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching result', error });
    }
  }

  async update(req, res) {
    try {
      const updated = await Result.findByIdAndUpdate(req.params.id, req.body, { new: true });
      res.status(200).json(updated);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update result', error });
    }
  }
}

module.exports = new ResultController();