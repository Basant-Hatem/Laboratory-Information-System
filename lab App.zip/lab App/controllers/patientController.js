

const Patient = require('../models/Patient');

class PatientController {
  async create(req, res) {
    try {
      const patient = new Patient(req.body);
      await patient.save();
      res.status(201).json(patient);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create patient', error });
    }
  }

  async getAll(req, res) {
    try {
      const patients = await Patient.find();
      res.status(200).json(patients);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch patients', error });
    }
  }

  async getById(req, res) {
    try {
      const patient = await Patient.findById(req.params.id);
      if (!patient) return res.status(404).json({ message: 'Patient not found' });
      res.status(200).json(patient);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching patient', error });
    }
  }

  async update(req, res) {
    try {
      const updated = await Patient.findByIdAndUpdate(req.params.id, req.body, { new: true });
      res.status(200).json(updated);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update patient', error });
    }
  }

  async delete(req, res) {
    try {
      await Patient.findByIdAndDelete(req.params.id);
      res.status(200).json({ message: 'Patient deleted' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete patient', error });
    }
  }
}

module.exports = new PatientController();