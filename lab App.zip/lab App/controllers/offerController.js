const Offer = require('../models/Offer');

class OfferController {
  async create(req, res) {
    try {
      const offer = new Offer(req.body);
      await offer.save();
      res.status(201).json(offer);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create offer', error });
    }
  }

  async getAll(req, res) {
    try {
      const offers = await Offer.find();
      res.status(200).json(offers);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch offers', error });
    }
  }

  async update(req, res) {
    try {
      const updated = await Offer.findByIdAndUpdate(req.params.id, req.body, { new: true });
      res.status(200).json(updated);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update offer', error });
    }
  }

  async delete(req, res) {
    try {
      await Offer.findByIdAndDelete(req.params.id);
      res.status(200).json({ message: 'Offer deleted' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete offer', error });
    }
  }
}

module.exports = new OfferController();