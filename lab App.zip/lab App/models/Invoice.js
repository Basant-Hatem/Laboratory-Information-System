const mongoose = require('mongoose');

const invoiceSchema = new mongoose.Schema({
  patientId: { type: mongoose.Schema.Types.ObjectId, ref: 'Patient', required: true },
  items: [{
    testId: { type: mongoose.Schema.Types.ObjectId, ref: 'Test' },
    price: Number
  }],
  total: Number,
  paid: { type: Boolean, default: false },
  date: { type: Date, default: Date.now }
}, { timestamps: true });

module.exports = mongoose.model('Invoice', invoiceSchema);