const mongoose = require('mongoose');

const offerSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: String,
  discount: Number,
  validUntil: Date
}, { timestamps: true });

module.exports = mongoose.model('Offer', offerSchema);